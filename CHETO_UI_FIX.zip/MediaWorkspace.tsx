import { Camera, CheckCircle2, Cpu, FileVideo, Film, Gauge, LoaderCircle, Scissors } from "lucide-react";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { formatFileSize } from "../../lib/format";
import type { ProjectBundle } from "../../project/contracts";
import type { LogLevel } from "../../types/diagnostics";
import { preferredPlaybackKind, type PlaybackPreference, type PlaybackSource, type ProxyStatus } from "../../playback/models";
import { cancelProxy, createProxy, getProxyStatus, onProxyDiagnostic, onProxyProgress, playbackErrorMessage, resolvePlaybackSource } from "../../playback/service";
import type { CameraPreview } from "../../smart-camera/models";
import { editedDurationUs, previewRange, removedDurationUs, selectionRange, type DraftTracks, type PreviewRange } from "../../editor/edl";
import type { EdlManifest } from "../../project/contracts";
import { Button } from "../Button";
import { Card } from "../Card";
import { SmartCutWorkspace } from "./SmartCutWorkspace";
import { SmartCameraWorkspace } from "./SmartCameraWorkspace";
import { VideoPlayer } from "./VideoPlayer";

interface MediaWorkspaceProps {
  bundle: ProjectBundle;
  onLog: (message: string, level?: LogLevel) => void;
  onNotify: (message: string, tone?: "success" | "error" | "info") => void;
}

const initialStatus: ProxyStatus = { message: null, metadata: null, processedUs: null, progress: null, state: "not_created" };

export function MediaWorkspace({ bundle, onLog, onNotify }: MediaWorkspaceProps) {
  const projectId = bundle.project.projectId;
  const [status, setStatus] = useState<ProxyStatus>(initialStatus);
  const [source, setSource] = useState<PlaybackSource | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [requestedSeekUs, setRequestedSeekUs] = useState<number | null>(null);
  const [cameraPreview, setCameraPreview] = useState<CameraPreview | null>(null);
  const [edl, setEdl] = useState<EdlManifest>(bundle.edl);
  const [activeTool, setActiveTool] = useState<"project"|"cut"|"camera">("project");
  const [previewMode, setPreviewMode] = useState<"original"|"result">("result");
  const [previewSize, setPreviewSize] = useState<"small"|"medium"|"large">("medium");
  const playheadUs = useRef(0);
  const [draftTracks, setDraftTracks] = useState<DraftTracks|null>(null);
  const [draftRange, setDraftRange] = useState<PreviewRange|null>(null);
  const [selectionInUs, setSelectionInUs] = useState<number|null>(null);
  const [selectionOutUs, setSelectionOutUs] = useState<number|null>(null);
  const progressBucket = useRef(-1);

  const resolveSource = useCallback(async (nextPreference: PlaybackPreference, currentStatus?: ProxyStatus) => {
    try {
      const effective = nextPreference === "proxy" && currentStatus && preferredPlaybackKind(currentStatus, nextPreference) === "original" ? "original" : nextPreference;
      const resolved = await resolvePlaybackSource(projectId, effective);
      setSource(resolved);
      setError(null);
    } catch (reason) {
      const message = playbackErrorMessage(reason);
      setError(message);
      onLog("PLAYBACK_ERROR", "error");
    }
  }, [onLog, projectId]);

  useEffect(() => {
    let disposed = false;
    let cleanup: (() => void)[] = [];
    void Promise.all([
      onProxyProgress((progress) => {
        if (progress.projectId !== projectId) return;
        setStatus((current) => ({ ...current, state: progress.status, progress: progress.progress, processedUs: progress.processedUs }));
        const bucket = Math.floor(progress.progress / 25);
        if (bucket > progressBucket.current && progress.status === "generating") {
          progressBucket.current = bucket;
          onLog("PROXY_PROGRESS");
        }
      }),
      onProxyDiagnostic((diagnostic) => {
        if (diagnostic.projectId === projectId) onLog(diagnostic.event, diagnostic.event.includes("FAILED") ? "error" : diagnostic.event.includes("FALLBACK") || diagnostic.event.includes("STALE") ? "warning" : "info");
      }),
    ]).then((unlisteners) => {
      if (disposed) unlisteners.forEach((unlisten) => unlisten());
      else cleanup = unlisteners;
    });
    void getProxyStatus(projectId).then((next) => {
      if (disposed) return;
      setStatus(next);
      if (next.state === "stale") onLog("PROXY_STALE", "warning");
      return resolveSource("auto", next);
    }).catch((reason) => {
      if (!disposed) setError(playbackErrorMessage(reason));
    });
    return () => { disposed = true; cleanup.forEach((unlisten) => unlisten()); };
  }, [onLog, projectId, resolveSource]);

  const startProxy = async () => {
    setError(null);
    setStatus((current) => ({ ...current, state: "preparing", progress: 0 }));
    progressBucket.current = -1;
    try {
      const next = await createProxy(projectId);
      setStatus(next);
      if (next.state === "available") {
        await resolveSource("proxy", next);
        onNotify("Proxy de trabajo disponible");
      }
    } catch (reason) {
      const message = playbackErrorMessage(reason);
      setStatus((current) => ({ ...current, message, state: "error" }));
      setError(message);
      onNotify(message, "error");
    }
  };

  const stopProxy = async () => {
    try { setStatus(await cancelProxy(projectId)); onNotify("Cancelación solicitada", "info"); }
    catch (reason) { onNotify(playbackErrorMessage(reason), "error"); }
  };

  const durationUs = bundle.source.durationUs ?? 0;
  const recommend = durationUs >= 30 * 60 * 1_000_000 || bundle.source.fileSizeBytes >= 1_000_000_000;
  const isGenerating = status.state === "preparing" || status.state === "generating";
  const proxyAvailable = status.state === "available";
  const proxy = status.metadata?.proxy;
  const removedUs=removedDurationUs(edl.tracks.cuts,durationUs);
  const resultUs=editedDurationUs(durationUs,edl.tracks.cuts);
  const runPreview=(seconds:10|30)=>{const current=playheadUs.current;setDraftRange(previewRange(current,seconds,durationUs));setPreviewMode("result");setRequestedSeekUs(current);};
  const runSelection=()=>{const range=selectionRange(selectionInUs,selectionOutUs,durationUs);if(range){setDraftRange(range);setPreviewMode("result");setRequestedSeekUs(range.startUs);}};
  const updatePlayhead=useCallback((value:number)=>{playheadUs.current=value;},[]);
  const handlePlaybackError=useCallback((message:string)=>{setError(message);onLog("PLAYBACK_ERROR","error");},[onLog]);

  const proxyPanel=<Card className="p-5">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-line pb-4">
          <div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-cyan"><Film size={18} /></span><div><p className="text-[10px] font-bold uppercase tracking-[0.16em] text-cyan">Proxy de trabajo</p><h3 className="mt-1 font-bold text-ink">{proxyStateLabel(status.state)}</h3></div></div>
          <div className="flex flex-wrap gap-2">
            {!isGenerating && !proxyAvailable ? <Button onClick={() => void startProxy()}>{status.state === "stale" || status.state === "error" ? "Regenerar" : "Crear proxy"}</Button> : null}
            {isGenerating ? <Button onClick={() => void stopProxy()} variant="secondary">Cancelar</Button> : null}
            {source?.kind === "proxy" ? <Button onClick={() => void resolveSource("original")} variant="secondary">Usar original</Button> : null}
            {proxyAvailable && source?.kind !== "proxy" ? <Button onClick={() => void resolveSource("proxy", status)} variant="secondary">Usar proxy</Button> : null}
          </div>
        </div>
        {isGenerating ? <div className="mt-5"><div className="mb-2 flex justify-between text-xs font-semibold text-muted"><span>{status.state === "preparing" ? "Preparando" : "Generando"}</span><span>{status.progress === null ? "—" : `${Math.floor(status.progress)} %`}</span></div><div className="h-2 overflow-hidden rounded-full bg-canvas"><div className="h-full rounded-full bg-cyan transition-[width]" style={{ width: `${status.progress ?? 0}%` }} /></div></div> : null}
        <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-4">
          <ProxyDetail icon={<CheckCircle2 size={15} />} label="Estado" value={proxyStateLabel(status.state)} />
          <ProxyDetail icon={<Gauge size={15} />} label="Resolución" value={proxy ? `${proxy.width} × ${proxy.height}` : "—"} />
          <ProxyDetail icon={<Cpu size={15} />} label="Encoder" value={proxy?.encoder ?? "—"} />
          <ProxyDetail icon={<Film size={15} />} label="Tamaño" value={proxy ? formatFileSize(proxy.fileSizeBytes) : "—"} />
        </div>
        <p className="mt-5 text-xs text-muted">{recommend ? "Crear un proxy de trabajo puede mejorar la fluidez de edición." : "El archivo original puede reproducirse directamente."} El original siempre permanece como fuente maestra.</p>
      </Card>;
  const panel=activeTool==="project"?proxyPanel:activeTool==="cut"?<SmartCutWorkspace bundle={bundle} edl={edl} onDraftChange={(cuts)=>setDraftTracks(current=>({camera:current?.camera??[],cuts}))} onEdlChange={setEdl} onLog={onLog} onNotify={onNotify} onSeek={setRequestedSeekUs}/>:<SmartCameraWorkspace bundle={bundle} edl={edl} onDraftChange={(camera)=>setDraftTracks(current=>({camera,cuts:current?.cuts??[]}))} onEdlChange={setEdl} onLog={onLog} onNotify={onNotify} onPreview={setCameraPreview} onSeek={setRequestedSeekUs}/>;
  const tools=[{id:"project" as const,label:"Proyecto",icon:<FileVideo size={18}/>},{id:"cut" as const,label:"Cortes",icon:<Scissors size={18}/>},{id:"camera" as const,label:"Encuadre",icon:<Camera size={18}/>}];
  return <div className="grid h-[calc(100vh-9rem)] min-h-[620px] overflow-hidden rounded-xl border border-line bg-surface shadow-2xl xl:grid-cols-[112px_minmax(480px,1fr)_390px] xl:grid-rows-[minmax(0,1fr)_190px]">
    <nav className="flex gap-2 overflow-x-auto border-b border-line bg-canvas/60 p-2 xl:row-span-2 xl:flex-col xl:overflow-visible xl:border-b-0 xl:border-r"><p className="hidden px-2 py-3 text-[10px] font-bold uppercase tracking-[.15em] text-muted xl:block">Herramientas</p>{tools.map(tool=><button className={`flex min-w-24 flex-col items-center gap-1 rounded-lg px-2 py-3 text-[10px] font-semibold transition ${activeTool===tool.id?"bg-primary/15 text-cyan":"text-muted hover:bg-card hover:text-ink"}`} key={tool.id} onClick={()=>setActiveTool(tool.id)} type="button">{tool.icon}{tool.label}</button>)}</nav>
    <section className="min-h-0 overflow-auto bg-black/40 p-3 xl:col-start-2 xl:row-start-1"><div className="mb-3 flex flex-wrap items-center justify-between gap-2"><div className="flex items-center rounded-lg border border-line bg-canvas p-1"><button className={`rounded-md px-3 py-1.5 text-xs font-bold ${previewMode==="original"?"bg-primary text-white":"text-muted"}`} onClick={()=>setPreviewMode("original")} title="Reproduce el archivo fuente sin aplicar decisiones.">ORIGINAL</button><button className={`rounded-md px-3 py-1.5 text-xs font-bold ${previewMode==="result"?"bg-primary text-white":"text-muted"}`} onClick={()=>setPreviewMode("result")} title="Reproduce virtualmente los cambios guardados en el EDL.">RESULTADO ⓘ</button></div><div className="flex gap-1">{(["small","medium","large"] as const).map(size=><button className={`rounded border border-line px-2 py-1 text-[10px] font-bold uppercase ${previewSize===size?"text-cyan":"text-muted"}`} key={size} onClick={()=>setPreviewSize(size)}>{size==="small"?"Pequeño":size==="medium"?"Medio":"Grande"}</button>)}</div></div><div className={`mx-auto transition-[max-width] ${previewSize==="small"?"max-w-lg":previewSize==="medium"?"max-w-3xl":"max-w-5xl"}`}>{source?<VideoPlayer cameraPreview={cameraPreview} draftRange={draftRange} draftTracks={draftTracks} durationUs={source.durationUs} edl={edl} key={source.path} kind={source.kind} mode={previewMode} onError={handlePlaybackError} onTimeChange={updatePlayhead} path={source.path} seekToUs={requestedSeekUs}/>:<div className="grid aspect-video place-items-center rounded-xl bg-black"><LoaderCircle className="animate-spin text-cyan"/></div>}</div>{error?<p className="mt-2 text-sm text-danger">{error}</p>:null}</section>
    <aside className="min-h-0 overflow-auto border-l border-line bg-canvas/30 p-3 xl:col-start-3 xl:row-span-2 xl:row-start-1">{panel}</aside>
    <section className="overflow-auto border-t border-line bg-canvas/65 p-3 xl:col-start-2 xl:row-start-2"><div className="grid gap-3 lg:grid-cols-[1fr_auto]"><div><p className="text-[10px] font-bold uppercase tracking-[.14em] text-cyan" title="EDL: lista no destructiva de decisiones de edición.">Edición ⓘ · {previewMode==="result"?"Resultado":"Original"}</p><div className="mt-2 grid grid-cols-4 gap-2 text-xs"><Metric label="Cortes" value={String(edl.tracks.cuts.length)}/><Metric label="Tiempo eliminado" value={formatShort(removedUs)}/><Metric label="Encuadres" value={String(edl.tracks.camera.length)}/><Metric label="Duración final" value={formatShort(resultUs)}/></div></div><div className="flex max-w-[30rem] flex-wrap content-center justify-end gap-2" title="Prueba: simula cambios todavía no aplicados."><Button onClick={()=>setSelectionInUs(playheadUs.current)} variant="secondary">Inicio {selectionInUs===null?"—":formatShort(selectionInUs)}</Button><Button onClick={()=>setSelectionOutUs(playheadUs.current)} variant="secondary">Fin {selectionOutUs===null?"—":formatShort(selectionOutUs)}</Button><Button onClick={()=>runPreview(10)}>Probar 10 s</Button><Button onClick={()=>runPreview(30)} variant="secondary">Probar 30 s</Button><Button disabled={!selectionRange(selectionInUs,selectionOutUs,durationUs)} onClick={runSelection} variant="secondary">Probar selección</Button>{draftRange?<Button onClick={()=>setDraftRange(null)} variant="ghost">Cerrar prueba</Button>:null}</div></div></section>
  </div>;
}

function Metric({label,value}:{label:string;value:string}){return <div className="rounded-md border border-line bg-panel/40 p-2"><p className="text-[9px] font-bold uppercase text-muted">{label}</p><p className="mt-1 font-mono font-semibold text-ink">{value}</p></div>}
function formatShort(us:number){const total=Math.max(0,Math.floor(us/1_000_000));return `${String(Math.floor(total/60)).padStart(2,"0")}:${String(total%60).padStart(2,"0")}`}

function proxyStateLabel(state: ProxyStatus["state"]): string {
  return { available: "Disponible", cancelled: "Cancelado", error: "Error", generating: "Generando", not_created: "No creado", preparing: "Preparando", stale: "Desactualizado" }[state];
}

function ProxyDetail({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return <div className="rounded-lg border border-line bg-canvas/55 p-3"><div className="flex items-center gap-2 text-muted">{icon}<p className="text-[10px] font-bold uppercase tracking-[0.12em]">{label}</p></div><p className="mt-2 truncate text-sm font-semibold text-ink">{value}</p></div>;
}
